﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Models
{
    public class PostViewModel
    {
        public List<Subjects> passSubject { get; set; }
        public List<notes> passNote { get; set; }
    }
}